(function() {
    'use strict';
    /*
    * author:广州银云信息科技有限公司
    * 过滤器模块
    */
    angular.module('goku.filter', [])
})();
